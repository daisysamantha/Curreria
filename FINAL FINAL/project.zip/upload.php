<?php //filename:upload.php
	   $host = "localhost";
	   $user = "root";
	   $pass = "";
	   $name = "project";
       
$koneksi = mysqli_connect($host, $user, $pass, $name);

if(mysqli_connect_errno()) {
		  die("<br/> koneksi DB gagal:".mysqli_connect_error()."(".mysqli_connect_errno() .")");
	   } 

$judul = $_POST['judul'];
$ket   = $_POST['body'];

$file_name = $_FILES['gambar']['name'];
$file_size = $_FILES['gambar']['size'];
$file_tmp = $_FILES['gambar']['tmp_name'];

$file_ext = strtolower(end(explode(".",$file_name)));
$ext_boleh = array("jpg","jpeg","png","gif","bmp");

if(in_array($file_ext,$ext_boleh))
{
    //EXT FILE DIPERBOLEHKAN
	
	if($file_size<=2*1024*1024)
	{
	    // move file to new directory
		
		$sumber=$file_tmp;
		$tujuan="gambar/" . $file_name;
		move_uploaded_file($sumber,$tujuan);
		
		$sql="INSERT INTO gallery(title,body,file)
		      VALUES ('$judul','$ket','$tujuan')";	  
			  
	    mysqli_query($koneksi,$sql);
		
		if(mysqli_error($koneksi))
		{
		   echo "Upload Gambar Gagal.";
		   echo mysqli_error($koneksi);
		   die();
		}
		
		header('location:gallery_admin.php');
		
    }
	
	else
    {
		   echo "Ukuran Gambar Terlalu Besar . MAX 2 MB. ";
    }
}
	
	else
	{
	      echo "Jenis File yang di perbolehkan hanya gambar.";
    }
		
		

?>
