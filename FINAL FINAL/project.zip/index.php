<?php
session_start();
session_destroy();
?>

<head>
<title>Churreria</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div id="wrapper">
    	<div id="bg">
        &nbsp;
        </div>
    	<div id="header">
        	<div id="logo">
            	<img src="SOURCES/logo.jpg">
            </div>
        </div><!-- End of Header -->
        <div id="slider">
        	<div id="menu"> 
			     
            	<ul>
				    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="ourmenu.php">Our Menu</a></li>
					<li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
					<li><a href="login.php">Login for Admin</a></li>
					
			    </ul>
       </ul>
            </div>
            
            <div id="slider_image">
            <img src="SOURCES/slider-3.jpg">
            </div>
        </div><!-- End of Slider -->
			<div id="footer_bawah">
            <center>Copyright &copy; 2014 by Daisy Shendy Stevanus</center>
            </div>
    </div><!-- End of Wrapper -->
</body>
