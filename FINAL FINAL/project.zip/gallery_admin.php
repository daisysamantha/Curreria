<?php
session_start();
	   $host = "localhost";
	   $user = "root";
	   $pass = "";
	   $name = "project";
       
$koneksi = mysqli_connect($host, $user, $pass, $name);

if(mysqli_connect_errno()) {
		  die("<br/> koneksi DB gagal:".mysqli_connect_error()."(".mysqli_connect_errno() .")");
	   } 
	   
	   //jika session username belum dibuat, atau session username kosong
if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    //redirect ke halaman login
    header('location:login.php');
}	
	   
	   $sql = "SELECT * FROM gallery";
$hasil = mysqli_query($koneksi,$sql);

?>

<head>
<title>Churreria</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div id="wrapper">
    	<div id="bg">
        &nbsp;
        </div>
    	<div id="header">
        	<div id="logo">
            	<img src="SOURCES/logo.jpg">
            </div>
        </div><!-- End of Header -->
        <div id="slider">
        	<div id="menu"> 
            	<ul>
				    <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="ourmenu_admin.php">Our Menu</a></li>
					<li><a href="gallery_admin.php">Gallery</a></li>
					<li><a href="bukutamu_admin.php">Komentar</a></li>
					<li><a href="logout.php">Logout</a></li>
					</ul>
				
       </ul>
            </div>
            
        <div id="slider_image1">
            <h2>Admin Gallery</h2>

<form action="upload.php"
      method="POST";
	  enctype="multipart/form-data">
	  
Judul :
<input type="text"
       name="judul" /><br/>
	   
Keterangan :
<textarea name="body"></textarea><br/>

File :
<input type="file"
       name="gambar" />
	   
<input type="submit"
       name="simpan"
	   value="Save" />
	   
</form>

<br/>
<br/>


     <h2>Gallery</h2>

     <?php 
	      while($baris = mysqli_fetch_assoc($hasil)) {
	 ?>
	 
	 <br/>
	 <br/>
	 
<div class="frame">

    <img src="<?php echo $baris['file']; ?>" />
    <center><span class="title"><?php echo $baris['title']; ?></span></center>
    <center><span class="body"><?php echo $baris['body']; ?></span></center>

</div>

<?php
    }
?>

            </div><!--End of Slider Image-->
        </div><!-- End of Slider -->
			
		<div id="footer_bawah">
            <center>Copyright &copy; 2014 by Daisy Shendy Stevanus</center>
        </div>
    </div><!-- End of Wrapper -->
</body>





