<?php
session_start();
session_destroy();
?>

<head>
<title>Encounter Site</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div id="wrapper">
    	<div id="bg">
        &nbsp;
        </div>
    	<div id="header">
        	<div id="logo">
            	<img src="SOURCES/logo.jpg">
            </div>
        </div><!-- End of Header -->
        <div id="slider">
        	<div id="menu"> 
            	<ul>
                <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="ourmenu.php">Our Menu</a></li>
					<li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
					<li><a href="login.php">Login for Admin</a></li>
                </ul>
            </div>
            
            
            <div id="content_bawah">
                <center><h2>About Us</h2></center>
                	<div id="isi_content_bawah_kiri">
                    	<div class="box" id="atas">	
							While we were conducting our research in Indonesia, we have found that there was not one distinct place that everyone would go to once they thought of churros and chocolate. </br>
							Right there and then, we found a proposition for Indonesia's market for their own personal Chocolateria. </br>
							All recipes originated from Spain. We also have mouth-watering desserts, from tarts to pralines, and not to mention our long list of rich chocolate drinks to quench your thirst. </br></br></br>
						
						<center><h2>Our Main Product</h2></center>
							The word Churreria is derived from the Spanish word "churro". </br>
							Churro itself is sometimes referred to as Spanish doughnuts, fried dough pastry-based snack that originated from Spain. </br>
							For a long time, churro has been popular in many countries, such as Australia. </br>
							The Spanish usually have it every morning as their breakfast, served with and dipped in chocolate.</br>
							However, with the spread of mixed culture around the world, churro has become irresistible for morning, afternoon, or night.</br> 
							It may also be dipped in other mouth-watering sauces, such as caramel. </p>
						</div>
					</div><!-- End of isi_content_bawah_kiri -->
            </div><!-- End of content_bawah-->
        </div><!-- End of Slider -->
            <div id="footer_bawah">
            <center>Copyright &copy; 2014 by Daisy Shendy Stevanus</center>
            </div>
    </div><!-- End of Wrapper -->
</body>

