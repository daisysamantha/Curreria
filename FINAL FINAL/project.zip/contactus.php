<?php
session_start();
session_destroy();
?>

<head>
<title>Encounter Site</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<div id="wrapper">
    	<div id="bg">
        &nbsp;
        </div>
    	<div id="header">
        	<div id="logo">
            	<img src="SOURCES/logo.jpg">
            </div>
        </div><!-- End of Header -->
        <div id="slider">
        	<div id="menu"> 
            	<ul>
               <li><a href="index.php">Home</a></li>
                    <li><a href="aboutus.php">About Us</a></li>
                    <li><a href="ourmenu.php">Our Menu</a></li>
					<li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
					<li><a href="login.php">Login for Admin</a></li>
                </ul>
            </div>
        </div><!-- End of Slider -->
            
            <div id="content_bawah">
						<center>
						OFFICE<br>
						PT. Churreria<br>
						Jl. Pangeran Jayakarta No. 141 Blok F/10<br>
						Jakarta Pusat 10730, Indonesia<br><br>

						Phone : +62 (21) 6008291<br>
						Fax   : +62 (21) 6291860<br><br>

						FRANCHISE<br>
						cafe.churreria@gmail.com<br><br>

						CAREER<br>
						churreria.hrd@gmail.com<br><br></center></div>
						
						<div ALIGN = "CENTER">
                        <H2>Silahkan Mengisi Komentar Di Bawah Ini!</H2>
						</div>
						<HR>

						<form action="proses.php" method="post">
						<center><table>
						<tr>
						<td>NIM         </td>
						<td colspan="7"><input type="text" name="nim" size="40"></td>
						</tr>
						<tr>
						<td>Nama        </td>
						<td colspan="7"><input type="text" name="nama" size="40"></td>
						</tr>
						<tr>
						<td>Email       </td>
						<td colspan="7"><input type="text" name="email" size="40"></td>
						</tr>
						<tr>
						<td>Komentar    </td>
						<td><textarea cols="40" rows="5" name="komentar"></textarea></td>
						</tr>
						<tr>
						<br/>
						<br/>
						<td><input type="submit" name="proses" value="Kirim"></td>
						<td><input type="reset" value="Reset"></td>
						</tr>
						</table></center>
						</form>
            </div><!-- End of content_bawah-->
        </div><!-- End of Content -->
		
		 
		

            <div id="footer_bawah">
            <center>Copyright &copy; 2014 by Daisy Shendy Stevanus</center>
            </div>
    </div><!-- End of Wrapper -->
</body>
