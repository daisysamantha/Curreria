 <html>
<head>
<title>Data Masuk</title>
</head>
<body>

<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="project";
$koneksi=mysql_connect($host,$user,$password);
mysql_select_db($database,$koneksi);
//cek koneksi
if($koneksi){
//echo "Berhasil Terhubung";
}else{
echo "Gagal Terhubung";
}

$query=mysql_query("select * from comment");
$jumlah=mysql_num_rows($query);
echo "Jumlah Pesan : ".$jumlah;
echo "<hr>";
?>
<?php

     if (!isset($_SESSION['username']) || empty($_SESSION['username'])) {
    //redirect ke halaman login
    header('location:login.php');
}
?>
<?php
while($row=mysql_fetch_array($query))
{

 echo "Pesan ke-"; echo @$a=$a+1; echo "<br>";
 echo "NIM      :$row[nim]<br>";
 echo "Nama     :$row[nama]<br>";
 echo "E-mail   :$row[email]<br>";
 echo "Komentar :$row[komentar]<br>";
 echo "<hr>";
}
?>
<br/>
<a href="ourmenu_admin.php">Back</a>
</body>
</html>